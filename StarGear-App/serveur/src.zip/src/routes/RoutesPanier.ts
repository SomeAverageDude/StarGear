import { Router } from "express";
import {
    registerGame,
    getPanierByUserId,
    removeGame,
    clearPanier,
} from "../controllers/panierController.js";
import { getPaniers } from "../db/mongo.js";
import { ObjectId } from "mongodb";
import { authenticateToken } from "../middleware/jwtToken.js";

const router = Router();

router.post("/ajouter", async (req,res)=> {
    try {
        const{userId, jeu} = req.body;

        const panierCollection = getPaniers();

        const result = await registerGame(panierCollection, new ObjectId(userId),jeu);
        
        if(result.modifiedCount > 0 || result.upsertedCount > 0){
            res.status(200).json({message: "Jeu ajouté au panier"});
        } else {
            res.status(400).json({message: "Échec d'ajout du jeu"});
        }

    } catch(error){
        return res.status(500).json({ message: "Database error" });
    }
}
);

router.get("/recuperer",authenticateToken, async(req,res) =>{
    try {
        const userId = req.user?._id;

        const collectionPanier = getPaniers();

        const panier = getPanierByUserId(collectionPanier,userId);

        if (!panier){
            res.status(200).json({
                userId, 
                jeux:[],
                updatedAt: new Date()
            });
        }

        res.status(200).json(panier);
    }catch(error){
        return res.status(500).json({ message: "Database error" });
    }
}
);

router.delete("/enlever", async(req,res) =>{
    try {
        const{userId,gameId} = req.body;
        
        const collectionPanier = getPaniers();

    }catch(error){
        return res.status(500).json({message: "DataBase error"});
    }
}
);

export default router;